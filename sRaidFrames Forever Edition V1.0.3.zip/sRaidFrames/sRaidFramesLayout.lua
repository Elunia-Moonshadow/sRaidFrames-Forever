--[[
	sRaidFrames Layout Engine (WoW: Forever Edition)
	Original Authors: Saroz, Nevcairiel, Stolenlegacy
	WoW: Forever Port & Modernization: Elunia-Moonshadow
	License: GNU General Public License v2.0 (GPLv2) — see LICENSE.txt
]]
local L = LibStub("AceLocale-3.0"):GetLocale("sRaidFrames")
local Media = LibStub("LibSharedMedia-3.0")
local sRaidFrames = sRaidFrames

sRaidFrames.Layouts = {}

function sRaidFrames:RegisterLayout(name, data)
	self.Layouts[name] = data
	
	self.options.args.behaviour.args.layout.values = {}
	for _name, _data in pairs(self.Layouts) do
		self.options.args.behaviour.args.layout.values[_name] = _data.Name
	end
end

function sRaidFrames:SetLayout(name)
	if not self.Layouts[name] then
		name = "CTRA_WithBorders"
	end
	self.opt.Layout = name
	self.CurrentLayout = self.Layouts[name]
end

function sRaidFrames:ApplyLayout()
	local layout = self:GetLayout()
	local inParty = not IsInRaid()
	local w = self.opt.FrameWidth or layout.unitframeWidth
	local hpH = self.opt.HealthBarHeight or 12
	local mpH = self.opt.PowerBarHeight or 4
	local fontH = max(14, (self.opt.FontSize or 10) + 6)
	if inParty then
		w = math.max(135, math.floor(w * 1.45 + 0.5))
		hpH = hpH + 4
		mpH = mpH + 2
		fontH = fontH + 2
	end
	local pad = layout.HasBorders and 8 or (layout.unitframeWidth > 80 and 8 or 0)
	local h = fontH + hpH + mpH + pad
	local showPortrait = self.ShouldShowPortrait and self:ShouldShowPortrait()
	local portraitSize = showPortrait and math.max(24, math.min(48, h - pad)) or 0
	local frameW = w + (showPortrait and (portraitSize + 6) or 0)
	layout.unitframeWidth = frameW
	layout.unitframeHeight = h
	layout.headerWidth = frameW

	if not InCombatLockdown() then
		for _, f in pairs(self.groupframes) do
			f.header:SetAttribute("style-width", frameW)
			f.header:SetAttribute("style-height", h)
			f:SetWidth(frameW)
			if f.anchor then f.anchor:SetWidth(frameW) end
		end
	else
		self:ScheduleLeaveCombatAction("ApplyLayout")
	end
	for _, f in pairs(self.frames) do
		layout.StyleUnitFrame(f)
	end
	for unit in pairs(self:GetAllUnits()) do
		self:UpdateStatuses(unit)
	end
	self:SetSpacing()
end

function sRaidFrames:GetLayout()
	if not self.CurrentLayout then
		self:SetLayout(self.opt.Layout)
	end
	return self.CurrentLayout
end

local function ApplyCommonUnitStyle(f, padX, padY)
	if sRaidFramesCompat and sRaidFramesCompat.AttachSafeUnitBackdrop then
		sRaidFramesCompat.AttachSafeUnitBackdrop(f)
	end
	local opt = sRaidFrames.opt
	local inParty = not IsInRaid()
	local w = opt.FrameWidth or 90
	local hpH = opt.HealthBarHeight or 12
	local mpH = opt.PowerBarHeight or 4
	local fontSize = opt.FontSize or 10
	local titleH = math.max(14, fontSize + 6)
	if inParty then
		w = math.max(135, math.floor(w * 1.45 + 0.5))
		hpH = hpH + 4
		mpH = mpH + 2
		titleH = titleH + 2
	end
	local iconSize = (opt.AuraIconSize or 13) + (inParty and 2 or 0)
	local debuffSize = iconSize + 2
	local buffSize = math.max(9, iconSize - 2)
	local barW = w - (padX * 2)
	local totalH = titleH + hpH + mpH + (padY * 2)
	local showPortrait = sRaidFrames.ShouldShowPortrait and sRaidFrames:ShouldShowPortrait()
	local portraitSize = showPortrait and math.max(24, math.min(48, totalH - (padY * 2))) or 0
	local leftOffset = padX + (showPortrait and (portraitSize + 6) or 0)
	local frameW = w + (showPortrait and (portraitSize + 6) or 0)

	local fontPath = (GameFontNormalSmall and GameFontNormalSmall:GetFont()) or STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
	f.title:SetFont(fontPath, fontSize, "")
	f.hpbar.text:SetFont(fontPath, math.max(8, fontSize - 1), "OUTLINE")
	f.statustext:SetFont(fontPath, math.max(8, fontSize - 2), "OUTLINE")

	sRaidFrames:SetWHP(f, frameW, totalH)
	sRaidFrames:SetWHP(f.title, barW, titleH, "TOPLEFT", f, "TOPLEFT", leftOffset, -padY)
	if f.portraitFrame then
		if showPortrait then
			f.portraitFrame:SetSize(portraitSize, portraitSize)
			f.portraitFrame:ClearAllPoints()
			f.portraitFrame:SetPoint("LEFT", f, "LEFT", padX, 0)
			if f.portraitBorder then
				local ringSize = math.floor(portraitSize * 1.38 + 0.5)
				f.portraitBorder:SetSize(ringSize, ringSize)
			end
			f.portraitFrame:Show()
		else
			f.portraitFrame:Hide()
		end
	end
	-- Buffs on the RIGHT (TOPRIGHT), Debuffs to the LEFT of Buffs
	sRaidFrames:SetWHP(f.buff1, buffSize, buffSize, "TOPRIGHT", f, "TOPRIGHT", -padX, -padY)
	sRaidFrames:SetWHP(f.buff2, buffSize, buffSize, "RIGHT", f.buff1, "LEFT", -1, 0)
	sRaidFrames:SetWHP(f.buff3, buffSize, buffSize, "RIGHT", f.buff2, "LEFT", -1, 0)
	sRaidFrames:SetWHP(f.buff4, buffSize, buffSize, "RIGHT", f.buff3, "LEFT", -1, 0)
	if f.buff5 then
		sRaidFrames:SetWHP(f.buff5, buffSize, buffSize, "RIGHT", f.buff4, "LEFT", -1, 0)
	end
	sRaidFrames:SetWHP(f.aura1, debuffSize, debuffSize, "TOPRIGHT", f.buff1, "TOPLEFT", -1, 0)
	sRaidFrames:SetWHP(f.aura2, debuffSize, debuffSize, "RIGHT", f.aura1, "LEFT", -1, 0)
	local showClassIcon = opt.ShowClassIcon and true or false
	local clsSize = showClassIcon and math.max(10, math.min(20, hpH)) or 0
	local levelW = inParty and math.max(26, math.floor(math.max(8, mpH + 2) * 2.8)) or 0
	local rightColW = math.max(clsSize, levelW)
	local rightReserve = (rightColW > 0) and (rightColW + 3) or 0
	local hpBarW = math.max(24, barW - rightReserve)

	sRaidFrames:SetWHP(f.hpbar, hpBarW, hpH, "TOPLEFT", f.title, "BOTTOMLEFT", 0, 0)
	if f.healbar then
		f.healbar:SetWidth(hpBarW)
		f.healbar:SetHeight(hpH)
	end
	sRaidFrames:SetWHP(f.mpbar, hpBarW, mpH, "TOPLEFT", f.hpbar, "BOTTOMLEFT", 0, 0)

	sRaidFrames:SetWHP(f.hpbar.text, hpBarW, hpH, "CENTER", f.hpbar, "CENTER", 0, 0)
	sRaidFrames:SetWHP(f.statustext, hpBarW, mpH, "CENTER", f.mpbar, "CENTER", 0, 0)
	if f.classIcon then
		local cSize = math.max(10, math.min(20, hpH))
		f.classIcon:SetSize(cSize, cSize)
		f.classIcon:ClearAllPoints()
		local iconOffsetX = 3 + math.floor((rightColW - cSize) / 2)
		f.classIcon:SetPoint("LEFT", f.hpbar, "RIGHT", iconOffsetX, 0)
	end
	if f.levelText then
		local lvlFontSize = math.max(7, math.min(11, mpH + 2))
		f.levelText:SetFont(fontPath, lvlFontSize, "OUTLINE")
		f.levelText:SetWidth(rightColW)
		f.levelText:SetHeight(math.max(mpH, lvlFontSize + 2))
		f.levelText:SetJustifyH("CENTER")
		f.levelText:ClearAllPoints()
		f.levelText:SetPoint("LEFT", f.mpbar, "RIGHT", 3, 0)
		if not inParty then
			f.levelText:Hide()
		end
	end
	if f.tankIcon then
		local tankSize = showPortrait and math.max(12, math.min(18, math.floor(portraitSize * 0.36))) or math.max(9, math.min(18, hpH - 1))
		f.tankIcon:SetSize(tankSize, tankSize)
		f.tankIcon:ClearAllPoints()
		if showPortrait and f.portraitFrame then
			f.tankIcon:SetPoint("BOTTOMRIGHT", f.portraitFrame, "BOTTOMRIGHT", 2, -2)
		else
			f.tankIcon:SetPoint("TOPLEFT", f.hpbar, "TOPLEFT", 1, 0)
		end
	end
	if f.leaderIcon then
		local leadSize = showPortrait and math.max(12, math.min(18, math.floor(portraitSize * 0.36))) or math.max(9, math.min(18, hpH - 1))
		f.leaderIcon:SetSize(leadSize, leadSize)
		f.leaderIcon:ClearAllPoints()
		if showPortrait and f.portraitFrame then
			f.leaderIcon:SetPoint("TOPLEFT", f.portraitFrame, "TOPLEFT", -2, 2)
		elseif f.tankIcon and f.tankIcon:IsShown() then
			f.leaderIcon:SetPoint("TOPLEFT", f.tankIcon, "TOPRIGHT", 1, 0)
		else
			f.leaderIcon:SetPoint("TOPLEFT", f.hpbar, "TOPLEFT", 1, 0)
		end
	end
	if f.voiceIcon then
		local voiceSize = showPortrait and math.max(12, math.min(16, math.floor(portraitSize * 0.34))) or math.max(10, math.min(14, hpH - 1))
		f.voiceIcon:SetSize(voiceSize, voiceSize)
		f.voiceIcon:ClearAllPoints()
		if showPortrait and f.portraitFrame then
			f.voiceIcon:SetPoint("BOTTOMLEFT", f.portraitFrame, "BOTTOMLEFT", -2, -2)
		else
			f.voiceIcon:SetPoint("BOTTOMLEFT", f.hpbar, "BOTTOMLEFT", 1, 0)
		end
	end
	if f.dbmAlertIcon then
		local dbmSize = math.max(12, math.min(hpH + 2, debuffSize))
		f.dbmAlertIcon:SetSize(dbmSize, dbmSize)
	end
end

sRaidFrames:RegisterLayout("CTRA_WithBorders", {
	Name = L["CT_RaidAssist"],
	HasBorders = true,
	StyleUnitFrame = function(f)
		ApplyCommonUnitStyle(f, 5, 4)
		f:SetBackdrop({ bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
									tile = true,
									tileSize = 16,
									edgeFile = Media:Fetch("border", sRaidFrames.opt.BorderTexture),
									edgeSize = 16,
									insets = { left = 5, right = 5, top = 5, bottom = 5 }
								})
								
		f:SetBackdropColor(sRaidFrames.opt.BackgroundColor.r, sRaidFrames.opt.BackgroundColor.g, sRaidFrames.opt.BackgroundColor.b, sRaidFrames.opt.BackgroundColor.a)
		f:SetBackdropBorderColor(sRaidFrames.opt.BorderColor.r, sRaidFrames.opt.BorderColor.g, sRaidFrames.opt.BorderColor.b, sRaidFrames.opt.BorderColor.a)
		f.hpbar.text:SetTextColor(sRaidFrames.opt.HealthTextColor.r, sRaidFrames.opt.HealthTextColor.g, sRaidFrames.opt.HealthTextColor.b, sRaidFrames.opt.HealthTextColor.a)
		if sRaidFrames.StyleNativeAuraContainers then
			sRaidFrames:StyleNativeAuraContainers(f, -4, -4)
		end
	end,
	unitframeWidth = 90,
	unitframeHeight = 40,
	headerWidth = 90,
	headerHeight = 15,
	debuffCount = 2,
	buffCount = 5,
})

sRaidFrames:RegisterLayout("CTRA_NoBorders", {
	Name = L["CT_RaidAssist (Without Borders)"],
	HasBorders = false,
	StyleUnitFrame = function(f)
		ApplyCommonUnitStyle(f, 0, 0)
		f:SetBackdrop({ bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
										tile = true, tileSize = 16,
										insets = { left = 0, right = 0, top = 0, bottom = 0 }
									})
		
		f:SetBackdropColor(sRaidFrames.opt.BackgroundColor.r, sRaidFrames.opt.BackgroundColor.g, sRaidFrames.opt.BackgroundColor.b, sRaidFrames.opt.BackgroundColor.a)
		f.hpbar.text:SetTextColor(sRaidFrames.opt.HealthTextColor.r, sRaidFrames.opt.HealthTextColor.g, sRaidFrames.opt.HealthTextColor.b, sRaidFrames.opt.HealthTextColor.a)
		if sRaidFrames.StyleNativeAuraContainers then
			sRaidFrames:StyleNativeAuraContainers(f, 0, 0)
		end
	end,
	unitframeWidth = 80,
	unitframeHeight = 32,
	headerWidth = 80,
	headerHeight = 15,
	debuffCount = 2,
	buffCount = 5,
})

sRaidFrames:RegisterLayout("CTRA_NoBordersWide", {
	Name = L["CT_RaidAssist (Without borders, Wide)"],
	HasBorders = false,
	StyleUnitFrame = function(f)
		ApplyCommonUnitStyle(f, 5, 4)
		f:SetBackdrop({ bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
										tile = true, tileSize = 16,
										insets = { left = 0, right = 0, top = 0, bottom = 0 }
									})
								
		f:SetBackdropColor(sRaidFrames.opt.BackgroundColor.r, sRaidFrames.opt.BackgroundColor.g, sRaidFrames.opt.BackgroundColor.b, sRaidFrames.opt.BackgroundColor.a)
		f.hpbar.text:SetTextColor(sRaidFrames.opt.HealthTextColor.r, sRaidFrames.opt.HealthTextColor.g, sRaidFrames.opt.HealthTextColor.b, sRaidFrames.opt.HealthTextColor.a)
		if sRaidFrames.StyleNativeAuraContainers then
			sRaidFrames:StyleNativeAuraContainers(f, -4, -4)
		end
	end,
	unitframeWidth = 90,
	unitframeHeight = 40,
	headerWidth = 90,
	headerHeight = 15,
	debuffCount = 2,
	buffCount = 5,
})

--[[
sRaidFrames:RegisterLayout("sRaidFrames", {
	Name = "sRaidFrames",
	HasBorders = true,
	StyleUnitFrame = function(f)
		sRaidFrames:SetWHP(f, 80, 30)
		sRaidFrames:SetWHP(f.title, 78, 13, "TOPLEFT", f, "TOPLEFT",  1, 0)
		sRaidFrames:SetWHP(f.aura1, 13, 13, "TOPRIGHT", f, "TOPRIGHT", -1, -1)
		sRaidFrames:SetWHP(f.aura2, 13, 13, "RIGHT", f.aura1, "LEFT", 0, 0)
		sRaidFrames:SetWHP(f.buff1, 13, 13, "TOPRIGHT", f, "TOPRIGHT", -1, -1)
		sRaidFrames:SetWHP(f.buff2, 13, 13, "RIGHT", f.buff1, "LEFT", 0, 0)
		sRaidFrames:SetWHP(f.buff3, 13, 13, "RIGHT", f.buff2, "LEFT", 0, 0)
		sRaidFrames:SetWHP(f.hpbar, 78, 12, "TOPLEFT", f.title, "BOTTOMLEFT", 0, 0)
		sRaidFrames:SetWHP(f.mpbar, 78, 4, "TOPLEFT", f.hpbar, "BOTTOMLEFT", 0, 0)
	
		sRaidFrames:SetWHP(f.hpbar.text, f.hpbar:GetWidth(), f.hpbar:GetHeight(), "CENTER", f.hpbar, "CENTER", 0, 0)
		sRaidFrames:SetWHP(f.statustext, f.mpbar:GetWidth(), f.mpbar:GetHeight(), "CENTER", f.mpbar, "CENTER", 0, 0)
		
		
		f:SetBackdrop({ bgFile = "Interface\\Addons\\sRaidFrames\\textures\\solidborder",
									tile = true,
									tileSize = 16,
									edgeFile = "Interface\\Addons\\sRaidFrames\\textures\\solidborder",
									edgeSize = 1,
									insets = { left = 1, right = 1, top = 1, bottom = 1 }
								})
								
		f:SetBackdropColor(sRaidFrames.opt.BackgroundColor.r, sRaidFrames.opt.BackgroundColor.g, sRaidFrames.opt.BackgroundColor.b, sRaidFrames.opt.BackgroundColor.a)
		f:SetBackdropBorderColor(sRaidFrames.opt.BorderColor.r, sRaidFrames.opt.BorderColor.g, sRaidFrames.opt.BorderColor.b, sRaidFrames.opt.BorderColor.a)
		f.hpbar.text:SetTextColor(sRaidFrames.opt.HealthTextColor.r, sRaidFrames.opt.HealthTextColor.g, sRaidFrames.opt.HealthTextColor.b, sRaidFrames.opt.HealthTextColor.a)
		if sRaidFrames.StyleNativeAuraContainers then
			sRaidFrames:StyleNativeAuraContainers(f, -4, -4)
		end
	end,
	unitframeWidth = 80,
	unitframeHeight = 30,
	headerWidth = 85,
	headerHeight = 15,
	debuffCount = 2,
	buffCount = 3,
})



sRaidFrames:RegisterLayout("Grid", {
	Name = "Dispell Grid",
	HasBorders = false,
	StyleUnitFrame = function(f)
		sRaidFrames:SetWHP(f, 26, 26)
		sRaidFrames:SetWHP(f.title, 80, 16, "TOPLEFT", f, "TOPLEFT",  5, -4)
		
		sRaidFrames:SetWHP(f.aura1, 16, 16, "CENTER", f, "CENTER", 0, 0)
		
		sRaidFrames:SetWHP(f.buff1, 12, 12, "TOPRIGHT", f, "TOPRIGHT", -4, -4)
		sRaidFrames:SetWHP(f.buff2, 12, 12, "RIGHT", f.buff1, "LEFT", 0, 0)
		sRaidFrames:SetWHP(f.buff3, 12, 12, "RIGHT", f.buff2, "LEFT", 0, 0)
		sRaidFrames:SetWHP(f.buff4, 12, 12, "RIGHT", f.buff3, "LEFT", 0, 0)
		
		sRaidFrames:SetWHP(f.hpbar, 80, 12, "TOPLEFT", f, "TOPLEFT", 0, 0)
		sRaidFrames:SetWHP(f.mpbar, 80, 4, "TOPRIGHT", f, "TOPRIGHT", 0, 0)
		
		f.hpbar:Hide()
		f.mpbar:Hide()
	
		sRaidFrames:SetWHP(f.title, f:GetWidth()-4, f.hpbar:GetHeight(), "CENTER", f, "CENTER", 0, 0)
		
		f.title:SetJustifyH("CENTER")
		f.title:SetNonSpaceWrap(true)
		
		f:SetBackdropColor(sRaidFrames.opt.BackgroundColor.r, sRaidFrames.opt.BackgroundColor.g, sRaidFrames.opt.BackgroundColor.b, sRaidFrames.opt.BackgroundColor.a)
		f:SetBackdropBorderColor(sRaidFrames.opt.BorderColor.r, sRaidFrames.opt.BorderColor.g, sRaidFrames.opt.BorderColor.b, sRaidFrames.opt.BorderColor.a)
		f.hpbar.text:SetTextColor(sRaidFrames.opt.HealthTextColor.r, sRaidFrames.opt.HealthTextColor.g, sRaidFrames.opt.HealthTextColor.b, sRaidFrames.opt.HealthTextColor.a)
		
		f:SetBackdrop( {
				      bgFile = "Interface\\Addons\\sRaidFrames\\textures\\solidborder", tile = true, tileSize = 16,
				      edgeFile = "Interface\\Addons\\sRaidFrames\\textures\\solidborder", edgeSize = 1,
				      insets = {left = 1, right = 1, top = 1, bottom = 1},
			      })
	end,
	unitframeWidth = 26,
	unitframeHeight = 26,
	headerWidth = 26,
	headerHeight = 15,
	debuffCount = 1,
	buffCount = 4,
})
]]--