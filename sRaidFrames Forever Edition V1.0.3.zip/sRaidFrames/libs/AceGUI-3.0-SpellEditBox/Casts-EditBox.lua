local AceGUI = LibStub("AceGUI-3.0")
do
	local Type = "Cast_EditBox"
	local Version = 10
	local filterCache = {}
	
	local function SafeGetSpellInfo(spellID)
		if sRaidFramesCompat and sRaidFramesCompat.GetSpellInfo then
			return sRaidFramesCompat.GetSpellInfo(spellID)
		elseif GetSpellInfo then
			return GetSpellInfo(spellID)
		end
		return nil
	end

	local function spellFilter(self, spellID)
		if( filterCache[spellID] ~= nil ) then return filterCache[spellID] end
		
		-- Hide all spells without a cast time
		local castTime = select(4, SafeGetSpellInfo(spellID)) or 0
		filterCache[spellID] = castTime > 0
		return filterCache[spellID]
	end
	
	-- I know theres a better way of doing this than this, but not sure for the time being, works fine though!
	local function Constructor()
		local self = AceGUI:Create("Predictor_Base")
		self.spellFilter = spellFilter
		return self
	end
	
	AceGUI:RegisterWidgetType(Type, Constructor, Version)
end
