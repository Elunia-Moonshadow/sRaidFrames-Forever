local AceGUI = LibStub("AceGUI-3.0")
do
	local Type = "Aura_EditBox"
	local Version = 10
	local filterCache = {}
	
	local function SafeGetSpellInfo(spellID)
		if sRaidFramesCompat and sRaidFramesCompat.GetSpellInfo then
			return sRaidFramesCompat.GetSpellInfo(spellID)
		elseif GetSpellInfo then
			return GetSpellInfo(spellID)
		end
		return nil
	end

	-- Tooltip scanning every single spell while it's loading would be not be that fun. Scanning spells as we search them (and get valid results)
	-- is a better solution since the results can be cached too.
	local function spellFilter(self, spellID)
		if( filterCache[spellID] ~= nil ) then return filterCache[spellID] end
		
		-- Very very few auras are over 100 yard range, and those are generally boss spells should be able to get away with this
		local maxRange = select(6, SafeGetSpellInfo(spellID)) or 0
		if( maxRange > 100 ) then
			filterCache[spellID] = true
			return false
		end
		
		filterCache[spellID] = true
		return true
	end
	
	-- I know theres a better way of doing this than this, but not sure for the time being, works fine though!
	local function Constructor()
		local self = AceGUI:Create("Predictor_Base")
		self.spellFilter = spellFilter
		return self
	end
	
	AceGUI:RegisterWidgetType(Type, Constructor, Version)
end
