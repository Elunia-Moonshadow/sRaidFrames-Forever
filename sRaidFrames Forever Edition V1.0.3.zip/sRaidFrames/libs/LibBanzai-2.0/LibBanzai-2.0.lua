--[[
Name: LibBanzai-2.0
Revision: $Revision: 45 $
Author(s): Rabbit (rabbit.magtheridon@gmail.com), maia
Documentation: http://www.wowace.com/index.php/Banzai-2.0_API_Documentation
SVN: http://svn.wowace.com/wowace/trunk/BanzaiLib/Banzai-2.0
Description: Aggro notification library.
Dependencies: LibStub
]]

-------------------------------------------------------------------------------
-- Locals
-------------------------------------------------------------------------------

local MAJOR_VERSION = "LibBanzai-2.0"
local MINOR_VERSION = 90100

if not LibStub then error(MAJOR_VERSION .. " requires LibStub.") end
local lib = LibStub:NewLibrary(MAJOR_VERSION, MINOR_VERSION)
if not lib then return end

lib.callbacks = lib.callbacks or {}
local callbacks = lib.callbacks
lib.frame = lib.frame or CreateFrame("Frame")
local frame = lib.frame

local _G = _G
local issecret = _G.issecretvalue or function() return false end
local UnitExists = _G.UnitExists
local UnitName = _G.UnitName
local UnitCanAttack = _G.UnitCanAttack
local UnitIsEnemy = _G.UnitIsEnemy
local UnitIsUnit = _G.UnitIsUnit
local IsInRaid = _G.IsInRaid
local IsInGroup = _G.IsInGroup or function() return _G.GetNumGroupMembers and _G.GetNumGroupMembers() > 0 end
local GetNumGroupMembers = _G.GetNumGroupMembers
local GetNumSubgroupMembers = _G.GetNumSubgroupMembers or _G.GetNumGroupMembers
local unpack = _G.unpack or table.unpack

-------------------------------------------------------------------------------
-- Roster
-------------------------------------------------------------------------------

local raidUnits = setmetatable({}, {__index =
	function(self, key)
		self[key] = ("raid%d"):format(key)
		return self[key]
	end
})
local raidPetUnits = setmetatable({}, {__index =
	function(self, key)
		self[key] = ("raidpet%d"):format(key)
		return self[key]
	end
})
local partyUnits = {"party1","party2","party3","party4"}
local partyPetUnits = {"partypet1","partypet2","partypet3","partypet4"}
local roster = {}
local needsUpdate = nil

-- If some pet has the same name as a person in the raid, they'll end up being
-- the same unit for the purposes of banzai, but we won't care right now.
local function SafeUnitExists(unit)
	if not unit then return false end
	local ok, ex = pcall(UnitExists, unit)
	return ok and not issecret(ex) and ex and true or false
end

local function addUnit(unit)
	if not SafeUnitExists(unit) then return end
	local ok, name = pcall(UnitName, unit)
	if not ok or not name or issecret(name) or name == "" then return end
	if not roster[name] then roster[name] = {} end
	roster[name][#roster[name] + 1] = unit
end

local function actuallyUpdateRoster()
	wipe(roster)
	addUnit("player")
	addUnit("pet")
	addUnit("focus")
	if IsInRaid() then
		for i = 1, GetNumGroupMembers() do
			addUnit(raidUnits[i])
			addUnit(raidPetUnits[i])
		end
	elseif IsInGroup() then
		for i = 1, GetNumSubgroupMembers() do
			addUnit(partyUnits[i])
			addUnit(partyPetUnits[i])
		end
	end
	needsUpdate = nil
end

local function updateRoster()
	needsUpdate = true
end

-------------------------------------------------------------------------------
-- Banzai
-------------------------------------------------------------------------------

local targets = setmetatable({}, {__index =
	function(self, key)
		self[key] = key .. "target"
		return self[key]
	end
})

local aggro = {}
local banzai = {}

local total = 0
local function updateBanzai(_, elapsed)
	total = total + elapsed
	if total > 0.2 then
		if needsUpdate then actuallyUpdateRoster() end
		for name, units in pairs(roster) do
			local unit = units[1]
			local targetId = targets[unit]
			if SafeUnitExists(targetId) then
				local ttId = targets[targetId]
				if unit == "focus" and UnitIsEnemy then
					local okE, isE = pcall(UnitIsEnemy, "focus", "player")
					if okE and not issecret(isE) and isE then
						ttId = "focustarget"
						targetId = "focus"
					end
				end
				if SafeUnitExists(ttId) then
					local okA, canAtk = pcall(UnitCanAttack, ttId, targetId)
					if okA and not issecret(canAtk) and canAtk then
						for n, u in pairs(roster) do
							local okU, same = pcall(UnitIsUnit, u[1], ttId)
							if okU and not issecret(same) and same then
								banzai[n] = (banzai[n] or 0) + 10
								break
							end
						end
					end
				end
			end
			if banzai[name] then
				if banzai[name] >= 5 then banzai[name] = banzai[name] - 5 end
				if banzai[name] > 25 then banzai[name] = 25 end
			end
		end
		for name, units in pairs(roster) do
			if banzai[name] and banzai[name] > 15 then
				if not aggro[name] then
					aggro[name] = true
					for i, v in next, callbacks do
						v(1, name, unpack(units))
					end
				end
			elseif aggro[name] then
				aggro[name] = nil
				for i, v in next, callbacks do
					v(0, name, unpack(units))
				end
			end
		end
		total = 0
	end
end

-------------------------------------------------------------------------------
-- Starting and stopping
-------------------------------------------------------------------------------

local running = nil
local function start()
	if running then return end
	updateRoster()
	frame:SetScript("OnUpdate", updateBanzai)
	frame:SetScript("OnEvent", updateRoster)
	frame:RegisterEvent("GROUP_ROSTER_UPDATE")
	frame:RegisterEvent("UNIT_PET")
	pcall(frame.RegisterEvent, frame, "PLAYER_FOCUS_CHANGED")
	running = true
end

local function stop()
	if not running then return end
	frame:SetScript("OnUpdate", nil)
	frame:SetScript("OnEvent", nil)
	frame:UnregisterAllEvents()
	running = nil
end

-------------------------------------------------------------------------------
-- API
-------------------------------------------------------------------------------

function lib:IsRunning() return running end
function lib:GetUnitAggroByUnitName(name)
	if not name or issecret(name) then return nil end
	return aggro[name]
end
function lib:GetUnitAggroByUnitId(unit)
	if not SafeUnitExists(unit) then return end
	local ok, name = pcall(UnitName, unit)
	if not ok or not name or issecret(name) then return nil end
	return aggro[name]
end

function lib:RegisterCallback(func)
	if type(func) ~= "function" then
		error(("Bad argument to :RegisterCallback, function expected, got %q."):format(type(func)), 2)
	end

	callbacks[#callbacks + 1] = func
	start()
end

function lib:UnregisterCallback(func)
	if type(func) ~= "function" then
		error(("Bad argument to :UnregisterCallback, function expected, got %q."):format(type(func)), 2)
	end

	local found = nil
	for i, v in next, callbacks do
		if v == func then
			table.remove(callbacks, i)
			found = true
			break
		end
	end
	if #callbacks == 0 then stop() end

	if not found then
		error("Bad argument to :UnregisterCallback, the provided function was not registered.", 2)
	end
end

-------------------------------------------------------------------------------
-- Initialization
-------------------------------------------------------------------------------

frame:SetScript("OnUpdate", nil)
frame:SetScript("OnEvent", nil)
frame:UnregisterAllEvents()
if #callbacks > 0 then start() end

